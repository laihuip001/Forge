# Forge Obsidian Plugins

> 推奨プラグインとその用途

## 必須プラグイン

### 1. Obsidian Git

GitHub連携用。自動commit/push/pullを実現。

**設定推奨値**:
- Auto pull interval: 10 minutes
- Auto commit interval: 10 minutes
- Auto push: ON

### 2. Dataview

プロンプトの動的検索・一覧表示。

**使用例**:
```dataview
TABLE trigger, tags
FROM "library"
WHERE category = "考える"
SORT file.mtime DESC
```

## 推奨プラグイン

### 3. Tag Wrangler

タグの一括管理・リネーム。

### 4. Folder Note

ディレクトリにノートを紐付け。各カテゴリの説明に使用。

### 5. Templater

プロンプト新規作成時のテンプレート挿入。

**設定**:
- Template folder: `/core/templates`

## プラグインインストール手順

1. Settings → Community plugins → Turn on community plugins
2. Browse → 各プラグイン名で検索
3. Install → Enable
