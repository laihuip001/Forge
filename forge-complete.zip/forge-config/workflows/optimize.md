---
name: optimize
description: 既存プロンプトの最適化
trigger: /optimize
---

## Steps

1. 現在のプロンプトを分析
2. 非効率な箇所を特定
3. 最適化版を生成
4. 差分を表示
5. 承認を待つ

## Optimization Targets

| Target | Action |
|--------|--------|
| 曖昧表現 | 定量化・具体化 |
| 重複指示 | 統合・削除 |
| 長い文 | 分割・簡潔化 |
| 暗黙の前提 | 明示化 |
| 欠落した制約 | 追加 |

## Output Format

```
## 最適化提案

### Before
{original prompt snippet}

### After
{optimized prompt snippet}

### 変更理由
- ...
```
