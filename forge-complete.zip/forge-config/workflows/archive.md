---
name: archive
description: プロンプトをライブラリに保存
trigger: /archive
---

## Steps

1. プロンプト構造を検証（YAML + XML）
2. パスとファイル名をユーザーに確認
3. `/library/{path}/` に保存
4. `git add` + `git commit -m "Add: {filename}"`
5. 完了報告

## Path Structure

```
/library/
├── /🔎 見つける/
├── /🧠 考える/
│   ├── /📊 広げる/
│   └── /🎯 絞る/
├── /⚡ 働きかける/
│   ├── /🔧 固める/
│   └── /✨ 生み出す/
└── /🔄 振り返る/
```
