---
name: audit
description: プロンプトの品質監査
trigger: /audit
---

## Evaluation Criteria

| Criterion | Weight | Description |
|-----------|--------|-------------|
| CoT Integration | 30% | `<thinking>` の有無と深さ |
| Token Efficiency | 25% | 冗長表現の排除度 |
| Structural Clarity | 25% | XML構造の明確さ |
| Determinism | 20% | 同一入力→同一出力の保証 |

## Output Format

```
## 監査結果

**総合スコア**: XX/100

| 基準 | スコア | コメント |
|------|--------|----------|
| CoT Integration | XX/30 | ... |
| Token Efficiency | XX/25 | ... |
| Structural Clarity | XX/25 | ... |
| Determinism | XX/20 | ... |

## 改善提案
1. ...
2. ...
```
