# Forge

> Prompt Engineering IDE powered by Antigravity

## Overview

Forgeは、構造化されたプロンプトの設計・最適化・アーカイブを行う専用環境です。

## Philosophy

```
見つける → 考える → 働きかける → 振り返る
   │          │           │           │
   ▼          ▼           ▼           ▼
 起点      広げる/絞る   固める/生み出す   評価
```

### Free Energy Principle Alignment

- 知覚と認知は連続的（程度の差）
- 認知 = 発散（広げる）+ 収束（絞る）
- 運動 = 準備（固める）+ 創造（生み出す）
- 全ての行動は予測誤差の最小化

## Directory Structure

```
/Forge
├── /library/                      ← プロンプトライブラリ
│   ├── /🔎 見つける/                ← 起点：種を見つける
│   ├── /🧠 考える/                  ← 認知フェーズ
│   │   ├── /📊 広げる/              ← 発散：選択肢を増やす
│   │   └── /🎯 絞る/                ← 収束：選択肢を減らす
│   ├── /⚡ 働きかける/              ← 運動フェーズ
│   │   ├── /🔧 固める/              ← 準備：足場を固める
│   │   └── /✨ 生み出す/            ← 創造：価値を生み出す
│   └── /🔄 振り返る/                ← 評価：学びを得る
├── /core/                         ← テンプレート・モジュール
│   ├── /templates/
│   └── /modules/
├── /private/                      ← 個人設定（Git除外可）
└── /.antigravity/                 ← IDE設定
```

## Commands

| Command | Description |
|---------|-------------|
| `/archive` | プロンプトをライブラリに保存 |
| `/audit` | プロンプトの品質監査 |
| `/optimize` | プロンプトの最適化 |

## Prompt Format

### YAML Frontmatter

```yaml
---
id: unique-id
category: 見つける|考える|働きかける|振り返る
subcategory: 広げる|絞る|固める|生み出す|null
trigger: when to use this prompt
tags: []
version: 1.0
created: ISO timestamp
---
```

### XML Body

```xml
<prompt>
  <purpose>...</purpose>
  <system>...</system>
  <context>...</context>
  <thinking_process>...</thinking_process>
  <output_format>...</output_format>
  <constraints>...</constraints>
</prompt>
```

## Setup

1. Clone this repository
2. Copy `.env.example` to `.env` and configure
3. Replace `{{FORGE_ROOT}}` in config files with actual path
4. Open in Antigravity IDE
5. Start designing prompts

## Repository

https://github.com/laihuip001/Forge

## License

Private
